THE FORGOTTEN PATHS — COMING SOON PAGE

Files:
- index.html
- assets/forgotten-paths-logo.png

Preview:
Open index.html in a web browser.

Publish:
Upload index.html and the assets folder to a static hosting provider (for example, GitHub Pages, Netlify, or Cloudflare Pages). Keep the assets folder alongside index.html.

Domain:
The Forgotten Paths.com is not registered or connected by this package. To use it, register the domain with a domain registrar, then point its DNS to your chosen hosting provider. Domain names are not case-sensitive; the usual spelling would be theforgottenpaths.com if you prefer no spaces.
